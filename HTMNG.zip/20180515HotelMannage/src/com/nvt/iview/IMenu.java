package com.nvt.iview;

public interface IMenu {
	public abstract void mainMenu();

	public abstract void roomMenu();

	public abstract void customerMenu();

	public abstract void transactionMenu();
}
