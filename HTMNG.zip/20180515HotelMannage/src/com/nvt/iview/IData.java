package com.nvt.iview;

public interface IData {
	public int enterInterger(String message);

	public double enterDouble(String message);

	public String enterString(String message);
}
