package com.nvt.iview;

public interface IMessage {
	public abstract void showMessage(String message);
}
