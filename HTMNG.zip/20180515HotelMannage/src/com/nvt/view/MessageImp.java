package com.nvt.view;

import com.nvt.iview.IMessage;

public class MessageImp implements IMessage {

	@Override
	public void showMessage(String message) {
		// TODO Auto-generated method stub
		System.out.println(message);
	}

}
